import {LaunchNavigator} from "../uk.co.workingedge.phonegap.plugin.launchnavigator";
declare var launchnavigator:LaunchNavigator;