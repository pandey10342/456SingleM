var krms_config ={			
	'ApiUrl':"http://appetics.online/singlemerchant/api",			
	'DialogDefaultTitle':"Appetics",			
	'MerchantKeys':"c20cd81e12a5dd2c0e9a0c23713bc359",
	'debug': false
};